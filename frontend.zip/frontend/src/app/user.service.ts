import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from './Modal/user.modal';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  apiURL = "http://localhost:3000/";

  constructor(private _http:HttpClient) { }

  getAllUser():Observable<Array<User>>{
    return this._http.get<Array<User>>(this.apiURL+"getUser");
  }
  
  addUser(data:User):Observable<any>{
    return this._http.post(this.apiURL+"addUser",data);
  }

  getSingleUser(id:number):Observable<User>{
    return this._http.get<User>(this.apiURL+`getUser/${id}`);
  }

  updateUser(newRec:User,id:number):Observable<any>{
    return this._http.put(this.apiURL+`updateUser/${id}`,newRec)
  }
  deleteUser(id:number):Observable<any>{    
    return this._http.delete(this.apiURL+`deleteUser/${id}`)
  }
}
