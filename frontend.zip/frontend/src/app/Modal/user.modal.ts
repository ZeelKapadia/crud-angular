export class User{
    id:number;
    fullname:string;
    email:string;
    mobile:string;
}