import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { inherits } from 'util';
import { UserService } from '../user.service';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {

  id: number
  errorMessage: any;
  successMessage: any;
  userForm:FormGroup;
  isAddMode = true

  constructor(private userService: UserService, private activRout: ActivatedRoute) { }

  ngOnInit(): void {
    this.id = +this.activRout.snapshot.paramMap.get('id');
    this.init()
  }

  init(){
    if (this.id != null || this.id != undefined) {  
      this.isAddMode = false
      this.userService.getSingleUser(this.id).subscribe((res)=>{
        let records = res["data"];
        console.log(records[0]);
        
        this.userForm = new FormGroup({
          'fullname': new FormControl(records[0].fullname),
          'email': new FormControl(records[0].email),
          'mobile': new FormControl(records[0].mobile),
        })
      })  
  }
    this.isAddMode = true
  this.userForm = new FormGroup({
    'fullname': new FormControl('', [Validators.required]),
    'email': new FormControl('', [Validators.required, Validators.email]),
    'mobile': new FormControl('', [Validators.required]),
  })
  }

  userSubmit(): void {
    if (this.userForm.valid) {

      if (this.id != null || this.id != undefined) {
        this.userService.updateUser(this.userForm.value, this.id).subscribe((res) => {
          this.successMessage = res.message;
        })
      }
      else {
        this.userService.addUser(this.userForm.value).subscribe((res) => {
          console.log(res);
          this.userForm.reset()
          this.successMessage = res.message
        })
      }
    }
    else {
      this.errorMessage = "All fields are required !"
    }
  }

}
