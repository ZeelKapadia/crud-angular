import { Component, OnInit } from '@angular/core';
import { User } from '../Modal/user.modal';
import { UserService } from '../user.service';

@Component({
  selector: 'app-read',
  templateUrl: './read.component.html',
  styleUrls: ['./read.component.css']
})
export class ReadComponent implements OnInit {

  userData: Array<User>;
  successMessage:any

  constructor(private userService:UserService) { }

  ngOnInit(): void {
    this.getUserData();
  }

  getUserData():void{
    this.userService.getAllUser().subscribe((response)=>{
      this.userData = response["data"]            
    })
  }

  onDelete(id:number){
    this.userService.deleteUser(id).subscribe((res)=>{
      this.successMessage = res.message;
      this.getUserData()
    })
  }

}
